package entities;

// Unidade ou setor onde o estoque fica (controle descentralizado).
public class LocalEstoque {

	private Integer id;
	private String nome;
	private String descricao;
	private boolean ativo = true;

	public LocalEstoque() {
	}

	public LocalEstoque(String nome, String descricao) {
		this.nome = nome;
		this.descricao = descricao;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}

}
