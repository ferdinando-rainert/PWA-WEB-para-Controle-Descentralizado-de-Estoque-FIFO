package entities;

public enum TipoMovimentacao {
	ENTRADA, SAIDA, TRANSFERENCIA, AJUSTE
}
