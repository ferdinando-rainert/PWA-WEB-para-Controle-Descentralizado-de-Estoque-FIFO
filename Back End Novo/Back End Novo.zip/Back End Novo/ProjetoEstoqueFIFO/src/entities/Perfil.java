package entities;

public enum Perfil {
	ADMIN, GESTOR, OPERADOR
}
