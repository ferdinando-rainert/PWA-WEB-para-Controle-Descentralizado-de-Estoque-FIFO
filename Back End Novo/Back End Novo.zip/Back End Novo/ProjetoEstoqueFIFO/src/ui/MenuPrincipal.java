package ui;

public class MenuPrincipal {

	public static void menu() {

		System.out.println("===== SISTEMA DE ESTOQUE FIFO =====");
		System.out.println("1 - MENU PRODUTO");
		System.out.println("2 - MENU LOCAL DE ESTOQUE");
		System.out.println("3 - MENU ESTOQUE (ENTRADA / SAÍDA FIFO)");
		System.out.println("4 - MENU USUÁRIO");
		System.out.println("0 - SAIR");

	}

}
