package ui;

public class MenuUsuario {

	public static void menu() {

		System.out.println("===== MENU USUÁRIO =====");
		System.out.println("1 - Cadastrar Usuário");
		System.out.println("2 - Listar Usuários");
		System.out.println("0 - Voltar");

	}

}
