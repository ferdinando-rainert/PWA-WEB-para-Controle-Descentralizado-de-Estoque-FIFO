package ui;

public class MenuProduto {

	public static void menu() {

		System.out.println("===== MENU PRODUTO =====");
		System.out.println("1 - Cadastrar Produto");
		System.out.println("2 - Listar Produtos");
		System.out.println("3 - Atualizar Produto");
		System.out.println("4 - Inativar Produto");
		System.out.println("0 - Voltar");

	}

}
