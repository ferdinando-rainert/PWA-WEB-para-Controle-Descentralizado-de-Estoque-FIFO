package ui;

public class MenuLocal {

	public static void menu() {

		System.out.println("===== MENU LOCAL DE ESTOQUE =====");
		System.out.println("1 - Cadastrar Local");
		System.out.println("2 - Listar Locais");
		System.out.println("0 - Voltar");

	}

}
