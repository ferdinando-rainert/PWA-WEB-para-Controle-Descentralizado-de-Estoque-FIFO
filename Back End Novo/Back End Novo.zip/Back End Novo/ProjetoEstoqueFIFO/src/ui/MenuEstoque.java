package ui;

public class MenuEstoque {

	public static void menu() {

		System.out.println("===== MENU ESTOQUE =====");
		System.out.println("1 - Registrar Entrada (novo lote)");
		System.out.println("2 - Registrar Saída (FIFO)");
		System.out.println("3 - Transferir entre Locais");
		System.out.println("4 - Consultar Saldo (lotes em ordem FIFO)");
		System.out.println("5 - Histórico de Movimentações");
		System.out.println("0 - Voltar");

	}

}
