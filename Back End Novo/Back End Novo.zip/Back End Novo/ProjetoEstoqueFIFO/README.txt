PROJETO ESTOQUE FIFO (Java + JDBC + MySQL, console)

Pacotes (um arquivo por classe):
  Conexao      Conexao
  entities     Produto, Lote, LocalEstoque, SaldoLoteLocal, Usuario, Movimentacao, Perfil, TipoMovimentacao
  DAO          ProdutoDAO, LoteDAO, LocalEstoqueDAO, SaldoLoteLocalDAO, UsuarioDAO, MovimentacaoDAO
  service      EstoqueService (entrada, saída FIFO, transferência)
  ui           MenuPrincipal, MenuProduto, MenuLocal, MenuEstoque, MenuUsuario
  application  Main

Como rodar:
 1) No MySQL, execute o script ../BancoDeDados.txt (copie o conteúdo para o Workbench).
 2) No Eclipse: File > Import > Existing Projects, ou crie um Java Project e copie a pasta src.
    Coloque o mysql-connector-j (.jar) na pasta lib e adicione ao Build Path.
 3) Defina as variáveis de ambiente (Run Configurations > Environment):
      DB_URL=jdbc:mysql://localhost:3306/estoque_fifo
      DB_USER=root
      DB_PASSWORD=sua_senha
    Não coloque a senha dentro do código nem suba para o GitHub.
 4) Execute application.Main.
 Teste do FIFO: com os dados de exemplo, faça uma saída de 15 do produto 1 no local 1.
 Serão usados L001 (10) e L002 (5).
